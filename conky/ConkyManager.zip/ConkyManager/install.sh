#!/bin/bash

sudo dpkg -i realpath_8.25-2ubuntu3_16.04_all.deb
sudo dpkg -i conky-manager_2.4_136_ubuntu16.04.1_armhf.deb
conky-manager