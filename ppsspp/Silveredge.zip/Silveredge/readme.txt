Thank you for your interest in Silveredge. I hope you enjoy playing the game as much as I enjoyed creating it :)
One little disclaimer: please don't use any of the resources of this game without contacting me about it first, and any redisrtibution of the game must be free of costs to the user. I can be reached at andrewafy@gmail.com
--AndrewYY

Controls:
 - Menu:
   - d-pad: move
   - cross: enter
   - circle: cancel
 - Game:
   - d-pad/analog: move
   - cross: shoot
   - R:
     - held: track targets
     - released: fire missiles
   - start: pause
   - select: show controls

Known Issues:
 - Some errors when run in HBL (doesn't really matter, the game is signed now)

Wishlist:
 - More rigorous error returning
 - Speed optimization of game logic
 - Online highscores
 - Theatre mode
 - More enemies
 - More levels
 - Actual plot

Thanks to:
 - Alex Chan for the title background
 - All the beta testers
 - The developers of the countless tools  and libraries I used
 - Everyone who downloaded, that includes you ;)

Changelog:
 Version 1.1
 - bugfix: game no longer lags on resume from sleep mode
 - bugfix: options menu is a little more stable now
 - feature: recompiled as prx
 - feature: signed eboot.pbp
 Version 1.0
 - first release